from fastapi import APIRouter, Depends, HTTPException, Response
from sqlalchemy.orm import Session
from app.db.session import get_db
from app.models.deliveries import Delivery
from app.schemas.deliveries import DeliveryOut
from typing import List
from reportlab.lib.pagesizes import letter
from reportlab.pdfgen import canvas
from io import BytesIO
from reportlab.lib import colors
from fastapi.responses import StreamingResponse
router = APIRouter(prefix="/compliance", tags=["Compliance"])

@router.get("/report/pdf")
def generate_pdf_report(db: Session = Depends(get_db)):
    deliveries = db.query(Delivery).all()

    buffer = BytesIO()
    c = canvas.Canvas(buffer, pagesize=letter)
    width, height = letter
    y = height - 50

    # Title
    c.setFont("Helvetica-Bold", 20)
    c.drawString(40, y, "📦 Compliance Delivery Report")
    y -= 30
    c.setStrokeColor(colors.grey)
    c.setLineWidth(1)
    c.line(40, y, width - 40, y)
    y -= 20

    c.setFont("Helvetica", 11)

    for i, delivery in enumerate(deliveries):
        if y < 120:
            c.showPage()
            y = height - 50
            c.setFont("Helvetica", 11)

        # Delivery header
        c.setFont("Helvetica-Bold", 13)
        c.drawString(40, y, f"🚚 Delivery ID: {delivery.id}")
        y -= 20
        c.setFont("Helvetica", 11)
        c.drawString(60, y, f"Order ID: {delivery.order_id}")
        y -= 15
        c.drawString(60, y, f"Delivery Date: {delivery.delivery_date}")
        y -= 15
        c.drawString(60, y, f"Status: {delivery.status.capitalize()}")
        y -= 15

        # Temperature logs
        temp_logs = delivery.temperature_logs or []
        c.drawString(60, y, f"Temperature Logs Count: {len(temp_logs)}")
        y -= 15

        if temp_logs:
            for log in temp_logs:
                c.drawString(80, y, f"• {log['timestamp']} : {log['temperature']} °C")
                y -= 15
        else:
            c.drawString(80, y, "• No logs available")
            y -= 15

        # Digital signature
        sig = delivery.digital_signature
        c.drawString(60, y, f"Digital Signature: {sig[:40]}..." if sig else "Digital Signature: None")
        y -= 25

        # Divider
        c.setStrokeColor(colors.lightgrey)
        c.setLineWidth(0.5)
        c.line(40, y, width - 40, y)
        y -= 20

    c.save()
    buffer.seek(0)

    return StreamingResponse(buffer, media_type="application/pdf", headers={
        "Content-Disposition": "attachment; filename=compliance_delivery_report.pdf"
    })
@router.get("/report/{delivery_id}", response_model=DeliveryOut)
def get_compliance_report(delivery_id: int, db: Session = Depends(get_db)):
    delivery = db.query(Delivery).filter(Delivery.id == delivery_id).first()

    if not delivery:
        raise HTTPException(status_code=404, detail="Delivery not found")

    if not delivery.temperature_logs or not delivery.digital_signature:
        raise HTTPException(
            status_code=400,
            detail="Compliance data incomplete: temperature logs or digital signature missing"
        )

    return delivery
@router.get("/report", response_model=List[DeliveryOut])
def generate_compliance_report(db: Session = Depends(get_db)):
    deliveries = db.query(Delivery).all()
    return deliveries
