from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from typing import List

from app.db.session import get_db
from app.models.deliveries import Delivery
from app.models.orders import Order
from app.schemas.deliveries import DeliveryCreate, DeliveryOut, DeliveryUpdate

router = APIRouter(prefix="/deliveries", tags=["Deliveries"])

@router.post("/", response_model=DeliveryOut)
def create_delivery(delivery: DeliveryCreate, db: Session = Depends(get_db)):
    # Check if the order exists
    order = db.query(Order).filter(Order.id == delivery.order_id).first()
    if not order:
        raise HTTPException(status_code=404, detail="Order not found")

    new_delivery = Delivery(**delivery.dict())
    db.add(new_delivery)
    db.commit()
    db.refresh(new_delivery)
    return new_delivery

@router.get("/", response_model=List[DeliveryOut])
def list_deliveries(skip: int = 0, limit: int = 100, db: Session = Depends(get_db)):
    deliveries = db.query(Delivery).offset(skip).limit(limit).all()
    return deliveries

@router.get("/{delivery_id}", response_model=DeliveryOut)
def get_delivery(delivery_id: int, db: Session = Depends(get_db)):
    delivery = db.query(Delivery).filter(Delivery.id == delivery_id).first()
    if not delivery:
        raise HTTPException(status_code=404, detail="Delivery not found")
    return delivery

@router.put("/{delivery_id}", response_model=DeliveryOut)
def update_delivery(delivery_id: int, delivery_update: DeliveryUpdate, db: Session = Depends(get_db)):
    delivery = db.query(Delivery).filter(Delivery.id == delivery_id).first()
    if not delivery:
        raise HTTPException(status_code=404, detail="Delivery not found")

    for key, value in delivery_update.dict(exclude_unset=True).items():
        setattr(delivery, key, value)

    db.commit()
    db.refresh(delivery)
    return delivery

@router.delete("/{delivery_id}", response_model=dict)
def delete_delivery(delivery_id: int, db: Session = Depends(get_db)):
    delivery = db.query(Delivery).filter(Delivery.id == delivery_id).first()
    if not delivery:
        raise HTTPException(status_code=404, detail="Delivery not found")

    db.delete(delivery)
    db.commit()
    return {"detail": "Delivery deleted successfully"}
