from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from app.db.session import get_db
from app.models.customer import Customer
from app.models.orders import Order
from app.models.deliveries import Delivery
from app.models.inventory import Inventory
from app.models.payments import Payment
from app.schemas.dashboard import DashboardResponse, DashboardStats, RecentOrder

router = APIRouter(prefix="/dashboard", tags=["Dashboard"])

@router.get("/", response_model=DashboardResponse)
def get_dashboard_data(db: Session = Depends(get_db)):
    # Stats
    total_customers = db.query(Customer).count()
    total_orders = db.query(Order).count()
    total_deliveries = db.query(Delivery).count()
    total_inventory_items = db.query(Inventory).count()
    total_payments = db.query(Payment).count()

    # Recent Orders (limit 5)
    recent_orders_query = (
        db.query(Order)
        .order_by(Order.created_at.desc())
        .limit(5)
        .all()
    )

    recent_orders = [
        RecentOrder(
            id=o.id,
            customer_name=o.customer.name,
            status=o.status,
            created_at=o.created_at
        )
        for o in recent_orders_query
    ]

    stats = DashboardStats(
        total_customers=total_customers,
        total_orders=total_orders,
        total_deliveries=total_deliveries,
        total_inventory_items=total_inventory_items,
        total_payments=total_payments,
    )

    return DashboardResponse(stats=stats, recent_orders=recent_orders)
