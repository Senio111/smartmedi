from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from fastapi.security import OAuth2PasswordRequestForm
from app.db.session import get_db
from app.schemas.users import UserCreate, UserOut, UserLogin
from app.models.users import User
from app.core.security import hash_password, verify_password, create_access_token
from fastapi import status
from fastapi.responses import JSONResponse
from app.schemas.users import UserUpdate
from app.core.auth import get_current_user
from app.core.security import hash_password
from typing import List
from app.schemas.users import UserOut


router = APIRouter(prefix="/users", tags=["Users"])

@router.post("/register", response_model=UserOut)
def register(user: UserCreate, db: Session = Depends(get_db)):
    if db.query(User).filter(User.username == user.username).first():
        raise HTTPException(status_code=400, detail="Username already exists")
    if db.query(User).filter(User.email == user.email).first():
        raise HTTPException(status_code=400, detail="Email already registered")

    hashed_pw = hash_password(user.password)
    db_user = User(
        username=user.username,
        email=user.email,
        hashed_password=hashed_pw,
        role=user.role
    )
    db.add(db_user)
    db.commit()
    db.refresh(db_user)
    return db_user

@router.post("/login")
def login(form_data: OAuth2PasswordRequestForm = Depends(), db: Session = Depends(get_db)):
    user = db.query(User).filter(User.username == form_data.username).first()
    if not user or not verify_password(form_data.password, user.hashed_password):
        raise HTTPException(status_code=401, detail="Invalid credentials")
    if not user.is_active:
        raise HTTPException(status_code=400, detail="User is inactive")

    token = create_access_token({"sub": user.username, "role": user.role})
    return {"access_token": token, "token_type": "bearer"}
@router.post("/logout")
def logout():
    """
    Instruct the client to remove token (logout).
    """
    return JSONResponse(content={"detail": "Successfully logged out"}, status_code=status.HTTP_200_OK)
@router.put("/me", response_model=UserOut)
def update_profile(update: UserUpdate, db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    if update.username:
        if db.query(User).filter(User.username == update.username).first():
            raise HTTPException(status_code=400, detail="Username already taken")
        current_user.username = update.username

    if update.email:
        if db.query(User).filter(User.email == update.email).first():
            raise HTTPException(status_code=400, detail="Email already in use")
        current_user.email = update.email

    if update.password:
        current_user.hashed_password = hash_password(update.password)

    db.commit()
    db.refresh(current_user)
    return current_user

@router.get("/", response_model=List[UserOut])
def get_all_users(db: Session = Depends(get_db)):
    users = db.query(User).all()
    return users