from fastapi import APIRouter
from . import inventory, deliveries, customers,orders, payments, users,dashboard, compliance

api_router = APIRouter()
api_router.include_router(inventory.router)
api_router.include_router(customers.router)
api_router.include_router(orders.router)
api_router.include_router(deliveries.router)
api_router.include_router(payments.router)
api_router.include_router(users.router)
api_router.include_router(dashboard.router)
api_router.include_router(compliance.router)
