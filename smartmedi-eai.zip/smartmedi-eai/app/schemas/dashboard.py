from pydantic import BaseModel
from typing import List, Optional
from datetime import datetime

class DashboardStats(BaseModel):
    total_customers: int
    total_orders: int
    total_deliveries: int
    total_inventory_items: int
    total_payments: int

class RecentOrder(BaseModel):
    id: int
    customer_name: str
    status: str
    created_at: datetime

class DashboardResponse(BaseModel):
    stats: DashboardStats
    recent_orders: List[RecentOrder]
