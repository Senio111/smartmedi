from pydantic import BaseModel
from typing import Optional
from datetime import datetime

class PaymentBase(BaseModel):
    order_id: int
    amount: float
    payment_method: str
    status: Optional[str] = "pending"
    transaction_ref: Optional[str] = None

class PaymentCreate(PaymentBase):
    pass

class PaymentUpdate(BaseModel):
    amount: Optional[float]
    payment_method: Optional[str]
    status: Optional[str]
    transaction_ref: Optional[str]

class PaymentOut(PaymentBase):
    id: int
    paid_at: datetime

    class Config:
        from_attributes = True
