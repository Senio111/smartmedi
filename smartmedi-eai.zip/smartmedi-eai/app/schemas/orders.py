from datetime import date
from pydantic import BaseModel
from typing import Optional
from app.schemas.customer import CustomerOut

class OrderBase(BaseModel):
    order_date: date
    customer_id: int
    status: Optional[str] = "pending"

class OrderCreate(OrderBase):
    pass

class OrderUpdate(BaseModel):
    order_date: Optional[date] = None
    status: Optional[str] = None

class OrderOut(OrderBase):
    id: int
    customer: CustomerOut  

    class Config:
        from_attributes = True
