from pydantic import BaseModel
from typing import Optional
from datetime import date, datetime

class InventoryBase(BaseModel):
    product_name: str
    quantity: int
    location: Optional[str] = None
    expiry_date: Optional[date] = None

class InventoryCreate(InventoryBase):
    pass

class InventoryUpdate(InventoryBase):
    pass

class InventoryOut(InventoryBase):
    id: int
    last_updated: Optional[datetime]

    class Config:
        orm_mode = True
