from datetime import date, datetime
from pydantic import BaseModel
from typing import Optional
from app.schemas.orders import OrderOut
from typing import List

class DeliveryBase(BaseModel):
    order_id: int
    delivery_address: str
    delivery_date: Optional[date] = None
    status: Optional[str] = "pending"

class TemperatureLogEntry(BaseModel):
    timestamp: str
    temperature: float

class DeliveryCreate(DeliveryBase):
    temperature_logs: Optional[List[TemperatureLogEntry]] = []
    digital_signature: Optional[str]
    

class DeliveryUpdate(BaseModel):
    delivery_address: Optional[str] = None
    delivery_date: Optional[date] = None
    status: Optional[str] = None

class DeliveryOut(DeliveryBase):
    id: int
    created_at: Optional[datetime]  
    updated_at: Optional[datetime] 
    temperature_logs: Optional[List[TemperatureLogEntry]] = []
    digital_signature: Optional[str]
    order: OrderOut

    class Config:
        from_attributes = True
