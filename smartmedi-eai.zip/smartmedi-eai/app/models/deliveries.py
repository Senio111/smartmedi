from sqlalchemy import Column, Integer, String, Date, TIMESTAMP, func, ForeignKey
from sqlalchemy.orm import relationship
from app.db.session import Base
from sqlalchemy import JSON

class Delivery(Base):
    __tablename__ = "deliveries"

    id = Column(Integer, primary_key=True, index=True)
    order_id = Column(Integer, ForeignKey("orders.id"), nullable=False)
    delivery_address = Column(String(255), nullable=False)
    delivery_date = Column(Date, nullable=True)
    status = Column(String(50), default="pending")
    created_at = Column(TIMESTAMP, server_default=func.now())
    updated_at = Column(TIMESTAMP, server_default=func.now(), onupdate=func.now())
    temperature_logs = Column(JSON, nullable=True)  # List of {timestamp, value}
    digital_signature = Column(String, nullable=True)

    # Relationship to order
    order = relationship("Order", back_populates="deliveries")
