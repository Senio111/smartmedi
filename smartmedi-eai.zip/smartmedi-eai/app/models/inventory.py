from sqlalchemy import Column, Integer, String, Date, DateTime, func
from app.db.session import Base

class Inventory(Base):
    __tablename__ = "inventory"

    id = Column(Integer, primary_key=True, index=True)
    product_name = Column(String(100), nullable=False)
    quantity = Column(Integer, nullable=False)
    location = Column(String(100))
    expiry_date = Column(Date)
    last_updated = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())
