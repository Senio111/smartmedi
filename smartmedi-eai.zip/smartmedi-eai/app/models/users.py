# app/models/users.py
from sqlalchemy import Column, Integer, String, Boolean, Enum, TIMESTAMP, func
from sqlalchemy.ext.declarative import declarative_base
import enum

from app.db.session import Base

class RoleEnum(str, enum.Enum):
    admin = "admin"
    staff = "staff"

class User(Base):
    __tablename__ = "users"

    id = Column(Integer, primary_key=True, index=True)
    username = Column(String(100), unique=True, nullable=False)
    email = Column(String(100), unique=True, nullable=False)
    hashed_password = Column(String, nullable=False)
    role = Column(Enum(RoleEnum), default=RoleEnum.staff)
    is_active = Column(Boolean, default=True)
    created_at = Column(TIMESTAMP, server_default=func.now())
